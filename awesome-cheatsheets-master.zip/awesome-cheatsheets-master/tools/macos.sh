sudo lsof -i -P | grep LISTEN # List all processes running on a specific port
