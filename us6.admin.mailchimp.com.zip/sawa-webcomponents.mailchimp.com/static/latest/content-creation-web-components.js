const mc_ca_buildHash = "6XH2WDHJAHGZIBS56U3YLDLTFA";
const mc_ca_baseUrl = `https://sawa-webcomponents.mailchimp.com/static/${mc_ca_buildHash}/content-creation-web-components/content-creation-web-components`;

(function (doc) {
  loadScript(doc, mc_ca_baseUrl, 'module');
  loadScript(doc, mc_ca_baseUrl, 'nomodule');
})(document);

function loadScript(doc, url, type) {
  // eslint-disable-next-line prefer-const -- Variable is updated later
  let scriptElm = doc.createElement('script');
  scriptElm.setAttribute('type', type);
  scriptElm.src = `${url}${type == 'module' ? '.esm.js' : '.js'}`;
  doc.head.appendChild(scriptElm);

  scriptElm.onerror = (_) => {
    console.warn(`content creation variable module script load failed, falling back to default`);
    loadDefault(doc, 'module');
  };
}

function loadDefault(doc, type) {
  const defaultScriptelm = doc.createElement('script');
  defaultScriptelm.setAttribute('type', type);
  defaultScriptelm.src = `${mc_ca_baseUrl}${type == 'module' ? '.esm.js' : '.js'}`;
  doc.head.appendChild(defaultScriptelm);

  defaultScriptelm.onError = (_) => {
    console.error(`content creation default experience load failed`);
  };
}

